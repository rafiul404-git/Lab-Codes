package services;

public interface LoginInterface {
    boolean login(String username, String password);
}
